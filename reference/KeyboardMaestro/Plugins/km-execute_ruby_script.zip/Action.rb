#!/usr/bin/ruby
_result = eval( %x[echo "${KMPARAM_Ruby_Code}"] )
print _result